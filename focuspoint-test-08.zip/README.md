Image Focus Point Field Type
==========================

This field type allows users to specify an image upload to use as a map.
The admin users are then able to drag and drop a point on the map that will be stored as a CSS % from the top left corner of the image.

Compatibility
-------------
This field type is bundled as an extension for BigTree 4.2 and higher.

Licensing
---------
This field type is publicly licensed under the [GNU Lesser General Public License](http://www.gnu.org/copyleft/lesser.html).