<?php
	$field["output"] = $field["input"];
